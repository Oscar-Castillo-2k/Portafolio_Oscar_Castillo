// crea el objeto alumno con sus atributos
const alumno = {
    nombre:"Oscar Castillo",
    profesion:"Ingeniería en Informática",
    correo:"oscar.castillo35@inacapmail.cl",
    numero:"+56 9 40967965",
    resumenLaboral:"Estudiante de instituto INACAP en la sede de Valparaíso de la carrera Ingeniería en Informática cursando el tercer semestre."
}

// muestra los atributos del objeto alumno
document.getElementById("nombreAlumno").innerHTML = alumno.nombre
document.getElementById("carreraAlumno").innerHTML = '<strong>Profesión:</strong> ' + alumno.profesion
document.getElementById("correoAlumno").innerHTML = '<strong>Correo:</strong> ' + alumno.correo
document.getElementById("numeroAlumno").innerHTML = '<strong>Número telefónico:</strong> ' + alumno.numero
document.getElementById("resumenAlumno").innerHTML = '<strong>Resumen Laboral:</strong> ' + alumno.resumenLaboral

// muestra los datos(conocimientos) de un array usando un for

const conocimientos = ["Visual Studio Code", "Word", "Excel", "PowerPoint", "Adobe Photoshop", "Adobe Illustrator", "Adobe After Effects", "Sony Vegas Pro"]

for (let i = 0; i < conocimientos.length; i++){
    document.getElementById(`${i}`).innerHTML = conocimientos[i]
}


// validador de RUT

function validarRut() {
    let rut = document.getElementById('rutInput').value.trim();

  // Expresión regular para validar el formato del RUT
    let rutRegex = /^(\d{1,2}\.?\d{3}\.?\d{3}-?[\dkK])$/;

    if (!rutRegex.test(rut)) {
    document.getElementById('result').innerText = 'El formato del RUT no es válido';
    return;
    }

  // Eliminar puntos y guiones del RUT
rut = rut.replace(/\./g,'').replace(/\-/g,'');

  // Extraer el dígito verificador
let dv = rut.slice(-1).toUpperCase();

  // Extraer la parte numérica del RUT
let rutNum = parseInt(rut.slice(0, -1));

  // Calcular el dígito verificador esperado
let m = 0;
let s = 1;
for (; rutNum; rutNum = Math.floor(rutNum / 10)) {
    s = (s + rutNum % 10 * (9 - m++ % 6)) % 11;
}
let dvEsperado = (s > 0) ? String(s - 1) : 'K';

  // Comparar el dígito verificador calculado con el ingresado
if (dv !== dvEsperado) {
    document.getElementById('result').innerText = 'El RUT ingresado no es válido';
    } else {
    document.getElementById('result').innerText = 'El RUT es válido';
    }
}


